package com.example.upgrad.firstrestAPI.Controllers;
import com.example.upgrad.firstrestAPI.Resources.userObject;
import com.example.upgrad.firstrestAPI.Source.sourceclass;

import java.util.HashMap;
import java.util.Map;


public class controllerone {

//------------------------Dont change the code enclosed----------------------------------------------------------------------------------------------------------------------------------------------------
    Map<Integer,userObject> internalmap = new HashMap<>();                  //
    controllerone() {                                                      //
        sourceclass s = new sourceclass();                                //
        internalmap = s.populate();                                       //
    }                                                                   //
//-------------------------Write your code below this line---------------------------------------------------------------------------------------------------------------------------------------------------------




}





