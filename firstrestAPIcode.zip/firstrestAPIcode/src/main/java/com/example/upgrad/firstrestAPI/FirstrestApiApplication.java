package com.example.upgrad.firstrestAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstrestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstrestApiApplication.class, args);
	}

}
