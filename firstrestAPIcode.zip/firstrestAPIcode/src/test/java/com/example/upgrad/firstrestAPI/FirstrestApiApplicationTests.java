package com.example.upgrad.firstrestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstrestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
